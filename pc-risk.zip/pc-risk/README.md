# pc_risk

npm run dev - start project
npm run build - build project
 
